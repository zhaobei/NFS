#!/bin/sh


mkdir /data/nfs_data


chmod 755 /data/nfs_data


rpm -Uvh ./nfs_util/*.rpm --nodeps --force 
rpm -Uvh ./rpcbind/*.rpm --nodeps --force 


cat <<EOF > /etc/exports
/data/nfs_data *(rw,sync,insecure,no_subtree_check,no_root_squash)
EOF


systemctl start rpcbind
systemctl start nfs

systemctl restart rpcbind
systemctl restart nfs


